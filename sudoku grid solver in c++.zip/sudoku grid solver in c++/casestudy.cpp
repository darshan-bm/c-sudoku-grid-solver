#include <iostream>
using namespace std;

const int N = 9;

typedef int Grid[N][N];

bool isValid(Grid& grid, int row, int col, int num) 
{
    for (int x = 0; x < N; x++)
    
        if (grid[row][x] == num)
		 return false;

    for (int y = 0; y < N; y++)
    
        if (grid[y][col] == num) 
		return false;

    int startRow = row - row % 3;
    
    int startCol = col - col % 3;
    
    for (int i = 0; i < 3; i++)
    
        for (int j = 0; j < 3; j++)
        
            if (grid[i + startRow][j + startCol] == num)
                return false;

    return true;
}

bool solveSudoku(Grid& grid, int row = 0, int col = 0) 
{
    if (row == N - 1 && col == N) 
	return true;

    if (col == N) 
	{
        row++;
        col = 0;
    }

    if (grid[row][col] > 0)
        return solveSudoku(grid, row, col + 1);

    for (int num = 1; num <= N; num++) 
	{
        if (isValid(grid, row, col, num)) 
		{
            grid[row][col] = num;
            
            if (solveSudoku(grid, row, col + 1))
                return true;
            
            grid[row][col] = 0;
        }
    }
    return false;
}

void printGrid(Grid& grid) 
{
    for (int row = 0; row < N; row++) 
	{
        if (row % 3 == 0 && row != 0)
            cout << "------+-------+------\n";
        
        for (int col = 0; col < N; col++) 
		{
            if (col % 3 == 0 && col != 0)
                cout << "| ";
             cout << grid[row][col] << " ";
        }
        cout << endl;
    }
}

void inputPuzzle(Grid& grid) 
{
    cout << "Enter Sudoku puzzle (9x9 grid, use 0 for empty cells):\n";
    for(int row = 0; row < N; row++) 
	{
        cout << "Row " << row+1 << ": ";
        for(int col = 0; col < N; col++) 
		{
            cin >> grid[row][col];
            if(grid[row][col] < 0 || grid[row][col] > 9) 
			{
                cout << "Invalid input! Use numbers 0-9.\n";
                exit(1);
            }
        }
    }
}

void playSudoku(Grid& grid) 
{
    int row, col, num;
    
    while(true) 
	{
        printGrid(grid);
        
        cout << "\nOptions:\n";
        cout << "1. Place a number\n";
        cout << "2. Solve the puzzle\n";
        cout << "3. Quit\n";
        
        int choice;
        cin >> choice;
        
        switch(choice) 
		{
            case 1:
                cout << "Enter row (1-9): ";
                cin >> row;
                cout << "Enter column (1-9): ";
                cin >> col;
                cout << "Enter number (1-9): ";
                cin >> num;
                
                if(row < 1 || row > 9 || col < 1 || col > 9 || num < 1 || num > 9) 
				{
                    cout << "Invalid input! Please use numbers 1-9.\n";
                    continue;
                }
                
                row--; col--;
                
                if(grid[row][col] != 0) 
				{
                    cout << "Cell is already filled!\n";
                    continue;
                }
                
                if(isValid(grid, row, col, num)) 
				{
                    grid[row][col] = num;
                }
                
				 else
				  
				{
                    cout << "Invalid placement! Number already exists.\n";
                }
                
                break;
                
            case 2:
            	
                if(solveSudoku(grid)) 
				{
                    printGrid(grid);
                    cout << "\nPuzzle solved successfully!\n";
                }
                
				 else 
				
				 {
                    cout << "No solution exists for this puzzle.\n";
                 }
                return;
            
			case 3:
            
			    cout << "Goodbye!\n";
                return;
            
			default:
            
			    cout << "Invalid choice. Please choose again.\n";
        }
    }
}

int main() 
{
    Grid grid = 
	{
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0}
    };

    cout << "Welcome to Sudoku!\n";
    
    cout << "Do you want to:\n";
    cout << "1. Input a puzzle\n";
    cout << "2. Start with an empty grid\n";
    
    int choice;
    cin >> choice;
    
    switch(choice) 
	{
        case 1:
            inputPuzzle(grid);
            break;
            
        case 2:
            cout << "Starting with an empty grid.\n";
            break;
            
        default:
        	
            cout << "Invalid choice. Starting with an empty grid.\n";
    }
    
    playSudoku(grid);
    
    return 0;
}

